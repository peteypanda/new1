import Viewer from "@/app/components/viewer"

export default function DockClerkViewer() {
  return <Viewer screenName="Dock Clerk" />
}

