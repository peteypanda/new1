import Viewer from "@/app/components/viewer"

export default function PID2Viewer() {
  return <Viewer screenName="PID 2" />
}

