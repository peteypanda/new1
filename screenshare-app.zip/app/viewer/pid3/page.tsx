import Viewer from "@/app/components/viewer"

export default function PID3Viewer() {
  return <Viewer screenName="PID 3" />
}

