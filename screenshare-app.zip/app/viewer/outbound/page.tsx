import Viewer from "@/app/components/viewer"

export default function OutboundViewer() {
  return <Viewer screenName="Outbound Dock" />
}

