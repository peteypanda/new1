import Viewer from "@/app/components/viewer"

export default function PID1Viewer() {
  return <Viewer screenName="PID 1" />
}

